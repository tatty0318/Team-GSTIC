export namespace Llaves {
  export const claveJWT = 'JWT@m1s10n';
  export const accountSid = 'AC144f98ad9bd77b92199d377902924ba0'
  export const authToken = 'cc57c20dbc10c8272fb55c5470619831';
}
